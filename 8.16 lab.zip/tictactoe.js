let playerTurn = true;
let computerMoveTimeout = 0;

const gameStatus = {
   MORE_MOVES_LEFT: 1,
   HUMAN_WINS: 2,
   COMPUTER_WINS: 3,
   DRAW_GAME: 4
};

window.addEventListener("DOMContentLoaded", domLoaded);

function domLoaded() {
   // Setup the click event for the "New game" button
   const newBtn = document.getElementById("newGameButton");
   newBtn.addEventListener("click", newGame);

   // Create click-event handlers for each game board button
   const buttons = getGameBoardButtons();
   for (let button of buttons) {
      button.addEventListener("click", function () { boardButtonClicked(button); });
   }

   // Clear the board
   newGame();
}

// Returns an array of 9 <button> elements that make up the game board. The first 3 
// elements are the top row, the next 3 the middle row, and the last 3 the 
// bottom row. 
function getGameBoardButtons() {
   return document.querySelectorAll("#gameBoard > button");
}

function checkForWinner() {
   const buttons = getGameBoardButtons();

   // Ways to win
   const possibilities = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
      [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
      [0, 4, 8], [2, 4, 6] // diagonals
   ];

   // Check for a winner first
   for (let indices of possibilities) {
      if (buttons[indices[0]].innerHTML !== "" &&
         buttons[indices[0]].innerHTML === buttons[indices[1]].innerHTML &&
         buttons[indices[1]].innerHTML === buttons[indices[2]].innerHTML) {

         // Found a winner
         if (buttons[indices[0]].innerHTML === "X") {
            return gameStatus.HUMAN_WINS;
         }
         else {
            return gameStatus.COMPUTER_WINS;
         }
      }
   }

   // See if any more moves are left
   for (let button of buttons) {
      if (button.innerHTML !== "X" && button.innerHTML !== "O") {
         return gameStatus.MORE_MOVES_LEFT;
      }
   }

   // If no winner and no moves left, then it's a draw
   return gameStatus.DRAW_GAME;
}

function newGame() {
   // Clear the computer's move timeout
   clearTimeout(computerMoveTimeout);
   computerMoveTimeout = 0;

   // Get all game board buttons
   const buttons = getGameBoardButtons();

   // Loop through all buttons to reset the board
   for (let button of buttons) {
      button.textContent = ""; // Clear the text content
      button.className = "";   // Remove the class name
      button.disabled = false; // Enable the button
   }

   // Set the player's turn to true
   playerTurn = true;

   // Update the turn information text
   const turnInfo = document.getElementById("turnInfo");
   turnInfo.textContent = "Your turn";
}

function boardButtonClicked(button) {
   if (playerTurn) {
      // Mark the button with "X" and apply the "x" class
      button.textContent = "X";
      button.classList.add("x");
      button.disabled = true; // Disable the button so it cannot be clicked again

      // Call switchTurn to let the computer make a move
      switchTurn();
   }
}

function switchTurn() {
   // Check the game status
   const status = checkForWinner();

   if (status === gameStatus.MORE_MOVES_LEFT) {
      // Switch turn from player to computer or vice versa
      if (playerTurn) {
         playerTurn = false;
         document.getElementById("turnInfo").textContent = "Computer's turn";

         // Make the computer move after 1 second
         computerMoveTimeout = setTimeout(makeComputerMove, 1000);
      } else {
         playerTurn = true;
         document.getElementById("turnInfo").textContent = "Your turn";
      }
   } else {
      // Game is over, display the appropriate message
      playerTurn = false; // Prevent the user from making further moves
      const turnInfo = document.getElementById("turnInfo");

      if (status === gameStatus.HUMAN_WINS) {
         turnInfo.textContent = "You win!";
      } else if (status === gameStatus.COMPUTER_WINS) {
         turnInfo.textContent = "Computer wins!";
      } else if (status === gameStatus.DRAW_GAME) {
         turnInfo.textContent = "Draw game";
      }
   }
}

function makeComputerMove() {
   const buttons = getGameBoardButtons();
   let availableButtons = [];

   // Find all available buttons
   for (let button of buttons) {
      if (button.textContent === "") {
         availableButtons.push(button);
      }
   }

   // Choose a random button from the available ones
   const randomIndex = Math.floor(Math.random() * availableButtons.length);
   const chosenButton = availableButtons[randomIndex];

   // Mark the button with "O" and apply the "o" class
   chosenButton.textContent = "O";
   chosenButton.classList.add("o");
   chosenButton.disabled = true; // Disable the button so it cannot be clicked again

   // Switch the turn back to the player
   switchTurn();
}
