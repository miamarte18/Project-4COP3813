window.addEventListener("DOMContentLoaded", domLoaded);

function domLoaded() {
   const addButton = document.getElementById("add-btn");
   const newTaskInput = document.getElementById("new-task");

   addButton.addEventListener("click", addBtnClick);
   newTaskInput.addEventListener("keyup", (event) => {
      if (event.key === "Enter") {
         addBtnClick();
      }
   });
}

function addBtnClick() {
   const newTaskInput = document.getElementById("new-task");
   const taskText = newTaskInput.value.trim();

   if (taskText !== "") {
      addTask(taskText);
      newTaskInput.value = ""; // Clear the input
      newTaskInput.focus();    // Refocus on the input
   }
}

function addTask(task) {
   const newLi = document.createElement("li");
   newLi.innerHTML = `<span class="task-text">${task}</span><button class="done-btn">&#10006;</button>`;

   const ol = document.querySelector("ol");
   ol.appendChild(newLi);

   const doneButton = newLi.querySelector(".done-btn");
   doneButton.addEventListener("click", removeTask);
}

function removeTask(event) {
   const li = event.target.parentNode;
   const ol = document.querySelector("ol");
   ol.removeChild(li);
}
