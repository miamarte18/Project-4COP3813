function parseScores(scoresString) {
   // TODO: Compete the function
   return scoresString.split(' ');
}

function buildDistributionArray(scoresArray) {
   // TODO: Compete the function
   const distribution = [0, 0, 0, 0 ,0];

   scoresArray.forEach(score => {
      const numericScore = parseInt(score, 10); 
      if (numericScore >= 90) {
         distribution[0] += 1;
      } else if (numericScore >= 80) {
         distribution[1] += 1;
      } else if (numericScore >= 70) {
         distribution[2] += 1;
      } else if (numericScore >= 60) {
         distribution[3] += 1;
      } else {
         distribution[4] += 1;
      }
   }); 
   return distribution;
}

function setTableContent(userInput) {
   // TODO: Compete the function
   const scoresArray = parseScores(userInput); 

   const distributionArray = buildDistributionArray(scoresArray);

   const firstRow = document.getElementById('first-row'); 
   const thirdRow = document.getElementById('third-row');

   firstRow.innerHTML = ''; 
   thirdRow.innerHTML = '';

   distributionArray.forEach((count, index) => {
      const barHeight = count * 10; 
      const barClass = `bar${index}`; 
      const barDiv = `<div style="height:${barHeight}px" class="${barClass}"></div>`;
      firstRow.innerHTML += `<td>${barDiv}</td>`;
   });

   distributionArray.forEach(count => {
      thirdRow.innerHTML += `<td>${count}</td>`;
   });
}

// TODO: Change the arguments for testing purposes
setTableContent("45 78 98 83 86 99 100 59");