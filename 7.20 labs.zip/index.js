function printSum(x, y) {
   // TODO: Add your solution here
   const numX = parseFloat(x); 
   const numY = parseFloat(y); 

   if (isNaN(numX) && isNaN(numY)) {
      console.log(`'${x}' and '${y}' are not numbers.`);   
   } else if (isNaN(numX)) { 
      console.log(`'${x}' is not a number.`);
   } else if (isNaN(numY)) {
      console.log(`'${y}' is not a number.`);
   }
   else {
      console.log(`Sum is ${numX + numY}.`);
   }
   
}

console.log("Testing printSum()...");

printSum(3, 6);            // 9
printSum(3.5, 6.1);        // 9.6
printSum("hello", 6);      // 'hello' is not a number
printSum(10, "hi");        // 'hi' is not a number
printSum("hello", "hi");   // 'hello' and 'hi' are not numbers


// Do NOT remove the following line
export default printSum;