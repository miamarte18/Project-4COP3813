function isStrongPassword(password) {

    if (password.length < 8) {
        return false;
    }

    if (password.toLowerCase().includes("password")) {
        return false;
    }

    if (!/[A-Z]/.test(password)) {
        return false;
    }

    if (!/[0-9]/.test(password)) {
        return false;
    }

    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
        return false;
    }

    for (let i = 0; i < password.length - 3; i++) {
        const sequence = password.slice(i, i + 4);
        if (/^(.)\1{3}$/.test(sequence)) {
            return false;
        }
    }

    return true;
}

// Example tests
console.log("Testing isStrongPassword()...");
console.log("Qwerty - " + isStrongPassword("Qwerty"));                   // false - Too short, no number, no special character
console.log("passwordQwerty - " + isStrongPassword("passwordQwerty"));   // false - Contains "password"
console.log("qwerty123 - " + isStrongPassword("qwerty123"));             // false - No uppercase chars, no special character
console.log("Qwerty123 - " + isStrongPassword("Qwerty123"));             // false - No special character
console.log("Qaaaa123! - " + isStrongPassword("Qaaaa123!"));             // false - Repeated sequence of four
console.log("Qwerty123! - " + isStrongPassword("Qwerty123!"));           // true
console.log("Abc123 - " + isStrongPassword("Abc123"));                   // false - Too short
console.log("Abc1234 - " + isStrongPassword("Abc1234"));                 // false - No special character
console.log("Abc1234! - " + isStrongPassword("Abc1234!"));               // true
console.log("Abcpassword123 - " + isStrongPassword("Abcpassword123"));   // false - Contains "password"
console.log("Abc123password - " + isStrongPassword("Abc123password"));   // false - Contains "password"
console.log("passwordAbc123 - " + isStrongPassword("passwordAbc123"));   // false - Contains "password"
console.log("passAbc1234! - " + isStrongPassword("passAbc1234!"));       // true

// Do NOT remove the following line:
export default isStrongPassword;