window.addEventListener("DOMContentLoaded", domLoaded);

function domLoaded() {
   // TODO: Complete the function
   const convertButton = document.getElementById('convertButton'); 
   const cInput =  document.getElementById('cInput'); 
   const fInput = document.getElementById('fInput');
   const errorMessage = document.getElementById('errorMessage');
   const weatherImage = document.getElementById('weatherImage');

   convertButton.addEventListener('click', () => {
      const celsiusValue = parseFloat(cInput.value); 
      const fahrenheitValue = parseFloat(fInput.value);

      if (!isNaN(celsiusValue)) {
         // Convert Celsius to Fahrenheit
         const fahrenheit = convertCtoF(celsiusValue);
         fInput.value = fahrenheit;
         cInput.value = '';
         updateWeatherImage(fahrenheit);
         errorMessage.textContent = '';
      } else if (!isNaN(fahrenheitValue)) {
         // Convert Fahrenheit to Celsius
         const celsius = convertFtoC(fahrenheitValue);
         cInput.value = celsius;
         fInput.value = '';
         updateWeatherImage(fahrenheitValue);
         errorMessage.textContent = '';
      } else {
         // Handle invalid input
         errorMessage.textContent = `${cInput.value || fInput.value} is not a number`;
         weatherImage.src = 'images/warm.png'; // Default image
      }
   });
   cInput.addEventListener('input', () => {
      fInput.value = '';
   }); 

   fInput.addEventListener('input', () => {
      cInput.value = '';
   })
}

function convertCtoF(degreesCelsius) {
   // TODO: Complete the function
   return degreesCelsius * 9/5 + 32;
}

function convertFtoC(degreesFahrenheit) {
   // TODO: Complete the function
   return (degreesFahrenheit - 32) * 5/9;
}
function updateWeatherImage(fahrenheit) {
   const weatherImage = document.getElementById('weatherImage');

   if (fahrenheit < 32) {
      weatherImage.src = 'images/cold.png';
   } else if (fahrenheit <= 50) {
      weatherImage.src = 'images/cool.png';
   } else {
      weatherImage.src = 'images/warm.png';
   }
}